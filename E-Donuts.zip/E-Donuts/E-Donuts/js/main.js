const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))

var carrinho = [];

function carregarDados() {
    carrinhoSalvo = JSON.parse(localStorage.getItem('carrinho'));

    if (carrinhoSalvo) carrinho = carrinhoSalvo;
}

function salvarEndereco() {
    const Endereco = {
        nome: document.getElementById('NomeForm').value,
        Telefone: document.getElementById('TelefoneForm').value,
        Email: document.getElementById('EmailForm').value,
        Estado: document.getElementById('Estado').value,
        Cidade: document.getElementById('CidadeForm').value,
        Cep: document.getElementById('cep').value,
        Bairro: document.getElementById('BairroForm').value,
        Referencia: document.getElementById('Ref').value,
    };

    localStorage.setItem('slvEndereco', JSON.stringify(Endereco));
}

function carregarEndereco() {
    const enderecoSalvo = localStorage.getItem('slvEndereco');

    if (enderecoSalvo) {
        const Endereco = JSON.parse(enderecoSalvo);

        document.getElementById('NomeForm').value = Endereco.nome;
        document.getElementById('TelefoneForm').value = Endereco.Telefone;
        document.getElementById('EmailForm').value = Endereco.Email;
        document.getElementById('Estado').value = Endereco.Estado;
        document.getElementById('CidadeForm').value = Endereco.Cidade;
        document.getElementById('cep').value = Endereco.Cep;
        document.getElementById('BairroForm').value = Endereco.Bairro;
        document.getElementById('Ref').value = Endereco.Referencia;
    }
}

function salvarDados() {
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
}

function limparCarrinho() {
    carrinho = [];
    localStorage.removeItem('carrinho');
}

function adicionarItemAoCarrinho(nome, preco, imagem) {
    const item = {
        nome: nome,
        preco: preco,
        imagem: imagem
    };

    carrinho.push({ ...item });

    salvarDados();
    alert('Item adicionado ao carrinho!');
}

function removerItemDoCarrinho(index) {
    carrinho.splice(index, 1);
    salvarDados();
    exibirCarrinho();
}

function exibirCarrinho() {
    const listaCarrinho = document.getElementById('listaCarrinho');
    listaCarrinho.innerHTML = '';

    carregarDados();

    if (carrinho.length === 0) {
        listaCarrinho.innerHTML = '<p class="text-center">Seu carrinho está vazio.</p>';
        return;
    }

    carrinho.forEach((item, index) => {
        const card = document.createElement('div');
        card.className = 'card mb-3 col-4 px-5';

        card.innerHTML = `
            <div class="justify-content-center align-items-center overflow-hidden" style="height: 200px; width: 100%;">
                <img src="${item.imagem}" class="object-fit-cover" style="height: 100%; width: 100%;" alt="${item.nome}">
            </div>
            <div class="card-body text-center">
                <h5 class="card-title">${item.nome}</h5>
                <p class="card-text"><strong>R$ ${item.preco.toFixed(2)}</strong></p>
                <button class="btn btn-danger" onclick="removerItemDoCarrinho(${index})">Remover</button>
            </div>
        `;

        document.getElementById('listaCarrinho').appendChild(card);
    });
}

function finalizarCompras() {
    const confirmacao = confirm('Tem certeza que deseja finalizar a compra?');
    if (confirmacao) {
        alert('Compra finalizada com sucesso!');

        limparCarrinho();

    }
}

function Estrutura2() {
    var elemento = document.getElementById('header');

    elemento.innerHTML = `
        <nav class="navbar bg-body-tertiary fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="../secoes/index.html"><img id="logo" src="../imagens/E-Donuts.png" /></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu de opções</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="../secoes/Donuts.html"><button id="button" type="button" class="btn btn-light">Donuts</button></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="../secoes/Lojas.html"><button id="button" type="button" class="btn btn-light"><i class="bi bi-shop"></i>
                                    Lojas</button></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="../secoes/Carrinho.html"><button id="button" type="button" class="btn btn-light"><i class="bi bi-cart4"></i>
                                    Carrinho</button></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="../secoes/EndereçoEntrega.html"><button id="button" type="button" class="btn btn-light"><i class="bi bi-house"></i>
                                    Endereço</button></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" onclick="mudarTema()">
                                    <button id="mudarTema" type="button" class="btn btn-light"><i class="bi bi-toggle-off"></i> Mudar Tema</button>
                                 </a>
                             </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    `;

    // Adiciona a classe ao botão (se ele existir)
    var button = document.getElementById('button');
    if (button) {
        button.classList.add('btn-DarkTheme');
    }

}

function Estrutura1() {
    var elemento = document.getElementById('header')

    elemento.innerHTML = `
    <header>
     <nav class="navbar navbar-expand-lg" >
      <div class="container-fluid py-lg-3">
        <a class="navbar-brand" href="index.html"><img id="logo" src="../imagens/E-Donuts.png" /></a>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="../secoes/Donuts.html">
                <button id="button" type="button" class="btn btn-light">Donuts</button>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../secoes/Lojas.html">
                <button type="button" class="btn btn-light"><i class="bi bi-shop"></i> Lojas</button>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../secoes/Carrinho.html">
                <button id="button" type="button" class="btn btn-light"><i class="bi bi-cart4"></i> Carrinho</button>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../secoes/EndereçoEntrega.html">
                <button id="button" type="button" class="btn btn-light"><i class="bi bi-house"></i> Endereço</button>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="mudarTema()">
                <button id="mudarTema" type="button" class="btn btn-light"><i class="bi bi-toggle-on"></i> Mudar Tema</button>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    </header>
    `;

    var button = document.getElementById('button');
    if (button) {
        button.classList.add('btn-DarkTheme');
    }
}

function mudarCards() {
    var elementos = document.getElementsByClassName('col-md-4');

    for (var i = 0; i < elementos.length; i++) {
        elementos[i].classList.replace("col-md-6");
    }
}

function mudarTema() {
    var elemento = document.body;
    var header = document.getElementById('header');
    var button = document.getElementById('mudarTema');

    elemento.classList.toggle("dark-theme");

    const temaEscuroAtivo = elemento.classList.contains("dark-theme");

    localStorage.setItem("temaEscuro", temaEscuroAtivo);

    if (temaEscuroAtivo) {
        button.textContent = "Modo Claro";
        button.textContent = "Modo Escuro";
    }

    if (temaEscuroAtivo) {

        header.classList.add('bg-dark-theme');
        header.classList.remove('bg-light-theme');
        Estrutura2();
        mudarCards();
    } else {

        header.classList.add('bg-light-theme');
        header.classList.remove('bg-dark-theme');
        Estrutura1();
    }
}



